SAMUEL TEGEGNE PORTFOLIO
========================

RUN LOCALLY WITH XAMPP
1. Extract the folder named "samuel-portfolio".
2. Copy it into C:\xampp\htdocs\
3. Start Apache from the XAMPP Control Panel.
4. Open http://localhost/samuel-portfolio/

CONTACT FORM
- The contact form posts to send-message.php.
- Valid messages are appended to data/messages.csv.
- Open the CSV with a spreadsheet program to review submissions.
- The data folder is protected from direct web access by .htaccess on Apache.
- This local-storage approach works without configuring SMTP or PHP mail.
- For a public website, use a proper database or SMTP service, HTTPS, and
  server-level rate limiting; do not leave collected messages on a public server
  without access controls and a privacy notice.

CUSTOMIZE
- Edit text and sections in index.php.
- Edit colors and layout in assets/css/style.css. Main accent: --accent.
- Edit navigation behavior in assets/js/main.js.
- Replace the sample skill percentages, social links, and project cards with
  Samuel's real details. The project cards are illustrative placeholders.

The design is an original implementation inspired by the general dark,
sidebar-based portfolio layout of the supplied SnapFolio demo. It does not
include BootstrapMade's proprietary source files, images, or licensed assets.
