<?php
session_start();
function redirectToForm(string $status): never {
    header('Location: index.php?error=' . rawurlencode($status) . '#contact');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php#contact'); exit; }
if (!empty($_POST['website'] ?? '')) { header('Location: index.php?sent=1#contact'); exit; }
$token = (string)($_POST['csrf_token'] ?? '');
if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) { redirectToForm('invalid'); }
$name = trim((string)($_POST['name'] ?? ''));
$email = trim((string)($_POST['email'] ?? ''));
$subject = trim((string)($_POST['subject'] ?? ''));
$message = trim((string)($_POST['message'] ?? ''));
if ($name === '' || mb_strlen($name) > 80 || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 120 || $subject === '' || mb_strlen($subject) > 120 || $message === '' || mb_strlen($message) > 4000) { redirectToForm('invalid'); }
$dir = __DIR__ . '/data';
if (!is_dir($dir) && !mkdir($dir, 0700, true)) { redirectToForm('failed'); }
$file = $dir . '/messages.csv';
$isNew = !file_exists($file);
$handle = fopen($file, 'ab');
if (!$handle) { redirectToForm('failed'); }
if (flock($handle, LOCK_EX)) {
    if ($isNew) { fputcsv($handle, ['received_at', 'name', 'email', 'subject', 'message']); }
    fputcsv($handle, [date('c'), $name, $email, $subject, $message]);
    fflush($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    header('Location: index.php?sent=1#contact');
    exit;
}
fclose($handle);
redirectToForm('failed');
