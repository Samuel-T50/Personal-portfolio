<?php
session_start();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$sent = isset($_GET['sent']) && $_GET['sent'] === '1';
$error = isset($_GET['error']) ? (string)$_GET['error'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Samuel Tegegne | Portfolio</title>
  <meta name="description" content="The personal portfolio of Samuel Tegegne.">
  <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Raleway:wght@500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<header class="sidebar" id="sidebar">
  <a class="brand" href="#home"><span class="brand-mark">ST</span><span>Samuel Tegegne</span></a>
  <div class="profile"><div class="avatar">ST</div><h1>Samuel Tegegne</h1><p>Student · Aspiring Developer</p></div>
  <nav class="side-nav" aria-label="Main navigation">
    <a class="active" href="#home"><i class="bi bi-house-door"></i> Home</a>
    <a href="#about"><i class="bi bi-person"></i> About</a>
    <a href="#skills"><i class="bi bi-gear"></i> Skills</a>
    <a href="#resume"><i class="bi bi-file-earmark-text"></i> Resume</a>
    <a href="#portfolio"><i class="bi bi-images"></i> Portfolio</a>
    <a href="#services"><i class="bi bi-hdd-stack"></i> Services</a>
    <a href="#contact"><i class="bi bi-envelope"></i> Contact</a>
  </nav>
  <div class="socials"><a href="#" aria-label="GitHub"><i class="bi bi-github"></i></a><a href="#" aria-label="LinkedIn"><i class="bi bi-linkedin"></i></a><a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a></div>
  <small class="copyright">© 2026 Samuel Tegegne</small>
</header>
<button class="mobile-toggle" id="mobileToggle" aria-label="Open navigation"><i class="bi bi-list"></i></button>
<main class="main-content">
  <section id="home" class="hero section-pad">
    <div class="hero-content"><span class="eyebrow">WELCOME TO MY WORLD</span><h2>Hi, I'm <span>Samuel Tegegne</span></h2><h3>I build ideas into digital experiences.</h3><p class="hero-copy">I'm a student and aspiring developer interested in technology, creative problem-solving, and building useful things for the web.</p><div class="hero-actions"><a class="btn-main" href="#portfolio">Explore my work <i class="bi bi-arrow-right"></i></a><a class="btn-quiet" href="#contact">Get in touch</a></div></div>
    <div class="hero-art"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><div class="hero-monogram">ST<span>✦</span></div><div class="floating-card"><i class="bi bi-code-slash"></i><div><b>Curious mind</b><small>Always learning</small></div></div><div class="hero-dot dot-a"></div><div class="hero-dot dot-b"></div></div>
    <a class="scroll-hint" href="#about"><span></span> SCROLL TO DISCOVER</a>
  </section>
  <section id="about" class="section-pad"><div class="section-heading"><span>GET TO KNOW ME</span><h2>About Me</h2><p>A little introduction to who I am and what I enjoy doing.</p></div>
    <div class="row g-4 align-items-center"><div class="col-lg-5"><div class="about-visual"><div class="about-initials">ST</div><div class="about-label"><i class="bi bi-lightbulb"></i> Learning by building</div></div></div><div class="col-lg-7"><div class="about-text"><h3>Curious about technology. Excited by what I can create.</h3><p>My name is Samuel Tegegne. I'm developing my skills in web design and programming, one project at a time. I enjoy understanding how things work and turning ideas into practical digital projects.</p><p>This portfolio is a place to introduce myself, share what I'm learning, and showcase projects as I grow.</p><div class="info-grid"><div><b>Name:</b> Samuel Tegegne</div><div><b>Focus:</b> Web development</div><div><b>Education:</b> Student</div><div><b>Interests:</b> Technology & design</div></div><a href="#contact" class="text-link">Let's connect <i class="bi bi-arrow-up-right"></i></a></div></div></div>
  </section>
  <section id="skills" class="section-pad section-muted"><div class="section-heading"><span>WHAT I'M LEARNING</span><h2>My Skills</h2><p>Skills and tools I'm exploring and improving.</p></div><div class="row g-4"><div class="col-md-6"><div class="skill-item"><div><b>HTML & CSS</b><span>Building blocks of the web</span></div><div class="progress"><div style="width:75%"></div></div></div><div class="skill-item"><div><b>PHP</b><span>Server-side fundamentals</span></div><div class="progress"><div style="width:45%"></div></div></div></div><div class="col-md-6"><div class="skill-item"><div><b>JavaScript</b><span>Interactive web experiences</span></div><div class="progress"><div style="width:40%"></div></div></div><div class="skill-item"><div><b>Bootstrap</b><span>Responsive page layouts</span></div><div class="progress"><div style="width:65%"></div></div></div></div></div><p class="small-note">Skill levels are editable examples. Update the percentages as your experience grows.</p></section>
  <section id="resume" class="section-pad"><div class="section-heading"><span>MY JOURNEY</span><h2>Resume</h2><p>Education, learning, and the experiences that shape my work.</p></div><div class="timeline"><article><span class="timeline-dot"></span><h3>Education</h3><h4>Student</h4><small>Currently studying</small><p>Building a strong foundation through school and independent learning.</p></article><article><span class="timeline-dot"></span><h3>Web Development</h3><h4>Self-directed learning</h4><small>Ongoing</small><p>Practicing HTML, CSS, JavaScript, PHP, and responsive web design through small projects.</p></article><article><span class="timeline-dot"></span><h3>What's next</h3><h4>More projects, more learning</h4><small>Future goals</small><p>Keep improving, collaborate with others, and create useful digital experiences.</p></article></div></section>
  <section id="portfolio" class="section-pad section-muted"><div class="section-heading"><span>SELECTED WORK</span><h2>My Portfolio</h2><p>A few project spaces to showcase work as it is completed.</p></div><div class="row g-4"><div class="col-md-6 col-xl-4"><article class="project-card"><div class="project-art art-one"><i class="bi bi-window-stack"></i></div><div class="project-info"><span>WEB DESIGN</span><h3>Personal Website</h3><p>A responsive website concept focused on clean layout and clear navigation.</p></div></article></div><div class="col-md-6 col-xl-4"><article class="project-card"><div class="project-art art-two"><i class="bi bi-journal-code"></i></div><div class="project-info"><span>PHP PROJECT</span><h3>Learning Project</h3><p>A space for a future PHP application and practical coding experiments.</p></div></article></div><div class="col-md-6 col-xl-4"><article class="project-card"><div class="project-art art-three"><i class="bi bi-palette"></i></div><div class="project-info"><span>CREATIVE</span><h3>Design Experiments</h3><p>Small visual explorations in color, typography, and user experience.</p></div></article></div></div></section>
  <section id="services" class="section-pad"><div class="section-heading"><span>WHAT I CAN EXPLORE</span><h2>Areas of Interest</h2><p>Things I enjoy learning about and developing further.</p></div><div class="row g-4"><div class="col-md-4"><div class="service-card"><i class="bi bi-code-square"></i><h3>Web Development</h3><p>Creating structured, responsive websites with modern web technologies.</p></div></div><div class="col-md-4"><div class="service-card"><i class="bi bi-easel"></i><h3>Web Design</h3><p>Exploring thoughtful layouts, typography, and accessible interfaces.</p></div></div><div class="col-md-4"><div class="service-card"><i class="bi bi-lightbulb"></i><h3>Problem Solving</h3><p>Learning to break down challenges and build practical solutions.</p></div></div></div></section>
  <section id="contact" class="section-pad section-muted"><div class="section-heading"><span>SAY HELLO</span><h2>Contact Me</h2><p>Have a question or want to connect? Send me a message.</p></div><div class="row g-4"><div class="col-lg-5"><div class="contact-panel"><h3>Let's start a conversation.</h3><p>Use the form and your message will be saved for Samuel to review.</p><div class="contact-detail"><i class="bi bi-envelope"></i><div><b>Message</b><span>Send through the form</span></div></div><div class="contact-detail"><i class="bi bi-geo-alt"></i><div><b>Location</b><span>Ethiopia</span></div></div></div></div><div class="col-lg-7"><form class="contact-form" action="send-message.php" method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>"><div class="hp-field" aria-hidden="true"><label>Leave this field empty<input name="website" tabindex="-1" autocomplete="off"></label></div>
    <?php if ($sent): ?><div class="alert alert-success">Your message was received. Thank you for reaching out!</div><?php elseif ($error === 'invalid'): ?><div class="alert alert-danger">Please check your details and try again.</div><?php elseif ($error === 'failed'): ?><div class="alert alert-danger">Sorry, your message could not be saved. Please try again.</div><?php endif; ?>
    <div class="row g-3"><div class="col-md-6"><label for="name">Your name</label><input id="name" name="name" type="text" maxlength="80" required></div><div class="col-md-6"><label for="email">Your email</label><input id="email" name="email" type="email" maxlength="120" required></div><div class="col-12"><label for="subject">Subject</label><input id="subject" name="subject" type="text" maxlength="120" required></div><div class="col-12"><label for="message">Message</label><textarea id="message" name="message" rows="6" maxlength="4000" required></textarea></div><div class="col-12"><button class="btn-main" type="submit">Send Message <i class="bi bi-send"></i></button></div></div></form></div></div></section>
  <footer class="footer"><span>© 2026 <b>Samuel Tegegne</b>. All rights reserved.</span><a href="#home">Back to top ↑</a></footer>
</main>
<script src="assets/js/main.js"></script>
</body></html>
